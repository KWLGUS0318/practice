const mainObject = {
  name : "export defalut example",
  fileName : "b.js",
  function : "export, import",
  explain : "자바스크립트는 내보내기 가져오기 기능을 지원합니다."
}


export default mainObject