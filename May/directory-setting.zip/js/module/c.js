export const cFunc = (a, b, c) => {
  return [a, b, c];
}

export let testVariable = 1;
export let moduleConnect = "this is connection";
