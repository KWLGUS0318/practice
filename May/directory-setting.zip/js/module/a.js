
export const aData = "a";